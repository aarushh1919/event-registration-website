# Event Registration Website

A full-stack event registration website built with Node.js, Express, and MySQL.

## Features

- User authentication (register/login)
- Event browsing and registration
- Admin dashboard for event management
- MySQL database backend
- RESTful API
- Responsive frontend design

## Prerequisites

- Node.js (v14 or higher)
- MySQL Server
- Git

## Installation

1. Clone or download this project
2. Install dependencies:
   ```bash
   npm install
   ```

## Database Setup

1. Create a MySQL database named `event_registration`
2. Import the database schema:
   ```bash
   mysql -u root -p event_registration < database.sql
   ```

## Configuration

1. Copy `.env` file and update the database credentials:
   ```
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=your_mysql_password
   DB_NAME=event_registration
   ```

2. Set your JWT secret key:
   ```
   JWT_SECRET=your_secret_key_here
   ```

## Running the Application

1. Start the server:
   ```bash
   npm start
   ```
   
   For development with auto-restart:
   ```bash
   npm run dev
   ```

2. Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

## Default Admin Account

- Username: `admin`
- Password: `admin123`

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login

### Events
- `GET /api/events` - Get all events
- `GET /api/events/:id` - Get specific event
- `POST /api/events` - Create event (admin only)
- `PUT /api/events/:id` - Update event (admin only)
- `DELETE /api/events/:id` - Delete event (admin only)

### Registrations
- `POST /api/registrations` - Register for event
- `GET /api/registrations/my` - Get user's registrations
- `DELETE /api/registrations/:id` - Cancel registration

### Admin
- `GET /api/admin/stats` - Get dashboard statistics
- `GET /api/admin/registrations` - Get all registrations

## Project Structure

```
├── server.js              # Main server file
├── package.json           # Dependencies and scripts
├── .env                   # Environment variables
├── database.sql           # Database schema
├── README.md              # Documentation
└── public/                # Frontend files
    ├── index.html
    ├── css/
    ├── js/
    └── admin/
```

## Technologies Used

- **Backend**: Node.js, Express.js
- **Database**: MySQL
- **Authentication**: JWT (JSON Web Tokens)
- **Password Hashing**: bcryptjs
- **Frontend**: HTML5, CSS3, JavaScript
- **Validation**: express-validator

## License

ISC
