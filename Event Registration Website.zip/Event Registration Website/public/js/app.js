// Global variables
let currentUser = null;
let currentEvents = [];
let currentRegistrations = [];

// API Base URL
const API_BASE = '/api';

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Check if user is logged in
    const token = localStorage.getItem('token');
    if (token) {
        const user = JSON.parse(localStorage.getItem('user'));
        if (user) {
            currentUser = user;
            updateUIForLoggedInUser();
        }
    }

    // Setup event listeners
    setupEventListeners();

    // Load initial data
    loadEvents();
    
    // Show home section by default
    showSection('home');
}

function setupEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const sectionId = this.getAttribute('href').substring(1);
            showSection(sectionId);
        });
    });

    // Auth buttons
    document.getElementById('loginBtn').addEventListener('click', () => showModal('loginModal'));
    document.getElementById('registerBtn').addEventListener('click', () => showModal('registerModal'));
    document.getElementById('logoutBtn').addEventListener('click', logout);

    // Auth forms
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    document.getElementById('registerForm').addEventListener('submit', handleRegister);
    document.getElementById('createEventForm').addEventListener('submit', handleCreateEvent);

    // Modal close buttons
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.addEventListener('click', function() {
            const modal = this.closest('.modal');
            closeModal(modal.id);
        });
    });

    // Close modal on outside click
    window.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            closeModal(e.target.id);
        }
    });
}

// Navigation
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });

    // Show selected section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
    }

    // Update nav links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
        }
    });

    // Load section-specific data
    switch(sectionId) {
        case 'events':
            loadEvents();
            break;
        case 'my-registrations':
            if (currentUser) {
                loadMyRegistrations();
            }
            break;
        case 'admin':
            if (currentUser && currentUser.role === 'admin') {
                loadAdminData();
            }
            break;
    }
}

// Authentication
async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    try {
        showLoading();
        const response = await fetch(`${API_BASE}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (response.ok) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            currentUser = data.user;
            
            updateUIForLoggedInUser();
            closeModal('loginModal');
            showToast('Login successful!', 'success');
            
            // Reset form
            document.getElementById('loginForm').reset();
        } else {
            showToast(data.error || 'Login failed', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

async function handleRegister(e) {
    e.preventDefault();
    
    const username = document.getElementById('registerUsername').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;

    try {
        showLoading();
        const response = await fetch(`${API_BASE}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, email, password })
        });

        const data = await response.json();

        if (response.ok) {
            closeModal('registerModal');
            showToast('Registration successful! Please login.', 'success');
            
            // Reset form
            document.getElementById('registerForm').reset();
            
            // Show login modal
            setTimeout(() => showModal('loginModal'), 1000);
        } else {
            showToast(data.error || 'Registration failed', 'error');
        }
    } catch (error) {
        console.error('Registration error:', error);
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    currentUser = null;
    
    updateUIForLoggedOutUser();
    showToast('Logged out successfully', 'success');
    showSection('home');
}

function updateUIForLoggedInUser() {
    document.getElementById('loginBtn').style.display = 'none';
    document.getElementById('registerBtn').style.display = 'none';
    document.getElementById('userInfo').style.display = 'flex';
    document.getElementById('username').textContent = currentUser.username;
    
    document.getElementById('myRegistrationsLink').style.display = 'block';
    
    if (currentUser.role === 'admin') {
        document.getElementById('adminLink').style.display = 'block';
    }
}

function updateUIForLoggedOutUser() {
    document.getElementById('loginBtn').style.display = 'block';
    document.getElementById('registerBtn').style.display = 'block';
    document.getElementById('userInfo').style.display = 'none';
    
    document.getElementById('myRegistrationsLink').style.display = 'none';
    document.getElementById('adminLink').style.display = 'none';
}

// Events
async function loadEvents() {
    try {
        showLoading();
        const response = await fetch(`${API_BASE}/events`);
        const events = await response.json();
        
        currentEvents = events;
        displayEvents(events);
        
        // Also load admin events if user is admin
        if (currentUser && currentUser.role === 'admin') {
            displayAdminEvents(events);
        }
    } catch (error) {
        console.error('Load events error:', error);
        showToast('Failed to load events', 'error');
    } finally {
        hideLoading();
    }
}

function displayEvents(events) {
    const eventsGrid = document.getElementById('eventsGrid');
    
    if (events.length === 0) {
        eventsGrid.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-calendar-times"></i>
                <h3>No events available</h3>
                <p>Check back later for upcoming events</p>
            </div>
        `;
        return;
    }

    eventsGrid.innerHTML = events.map(event => `
        <div class="event-card" onclick="showEventDetails(${event.id})">
            <div class="event-header">
                <div>
                    <h3 class="event-title">${event.title}</h3>
                </div>
                <span class="event-status status-${event.status}">${event.status}</span>
            </div>
            <div class="event-description">${event.description || 'No description available'}</div>
            <div class="event-details">
                <div class="event-detail">
                    <i class="fas fa-calendar"></i>
                    <span>${formatDate(event.date)}</span>
                </div>
                <div class="event-detail">
                    <i class="fas fa-clock"></i>
                    <span>${formatTime(event.time)}</span>
                </div>
                <div class="event-detail">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${event.location}</span>
                </div>
            </div>
            <div class="event-footer">
                <div class="event-participants">
                    <i class="fas fa-users"></i>
                    ${event.registered_count || 0}${event.max_participants ? `/${event.max_participants}` : ''} registered
                </div>
                <div class="event-actions">
                    ${currentUser ? 
                        `<button class="btn btn-primary" onclick="event.stopPropagation(); registerForEvent(${event.id})">
                            Register
                        </button>` :
                        `<button class="btn btn-outline" onclick="event.stopPropagation(); showModal('loginModal')">
                            Login to Register
                        </button>`
                    }
                </div>
            </div>
        </div>
    `).join('');
}

async function showEventDetails(eventId) {
    try {
        showLoading();
        const response = await fetch(`${API_BASE}/events/${eventId}`);
        const event = await response.json();
        
        const modal = document.getElementById('eventModal');
        const details = document.getElementById('eventDetails');
        
        details.innerHTML = `
            <h2>${event.title}</h2>
            <span class="event-status status-${event.status}">${event.status}</span>
            
            <div class="event-description" style="margin: 1.5rem 0;">
                ${event.description || 'No description available'}
            </div>
            
            <div class="event-details">
                <div class="event-detail">
                    <i class="fas fa-calendar"></i>
                    <span><strong>Date:</strong> ${formatDate(event.date)}</span>
                </div>
                <div class="event-detail">
                    <i class="fas fa-clock"></i>
                    <span><strong>Time:</strong> ${formatTime(event.time)}</span>
                </div>
                <div class="event-detail">
                    <i class="fas fa-map-marker-alt"></i>
                    <span><strong>Location:</strong> ${event.location}</span>
                </div>
                <div class="event-detail">
                    <i class="fas fa-users"></i>
                    <span><strong>Participants:</strong> ${event.registered_count || 0}${event.max_participants ? `/${event.max_participants}` : ''}</span>
                </div>
                ${event.created_by_name ? `
                    <div class="event-detail">
                        <i class="fas fa-user"></i>
                        <span><strong>Created by:</strong> ${event.created_by_name}</span>
                    </div>
                ` : ''}
            </div>
            
            <div style="margin-top: 2rem;">
                ${currentUser ? 
                    `<button class="btn btn-primary btn-full" onclick="registerForEvent(${event.id}); closeEventModal();">
                        Register for this Event
                    </button>` :
                    `<button class="btn btn-primary btn-full" onclick="showModal('loginModal'); closeEventModal();">
                        Login to Register
                    </button>`
                }
            </div>
        `;
        
        showModal('eventModal');
    } catch (error) {
        console.error('Show event details error:', error);
        showToast('Failed to load event details', 'error');
    } finally {
        hideLoading();
    }
}

function closeEventModal() {
    closeModal('eventModal');
}

async function registerForEvent(eventId) {
    if (!currentUser) {
        showModal('loginModal');
        return;
    }

    try {
        showLoading();
        const response = await fetch(`${API_BASE}/registrations`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({ event_id: eventId })
        });

        const data = await response.json();

        if (response.ok) {
            showToast('Successfully registered for event!', 'success');
            loadEvents(); // Reload events to update participant counts
        } else {
            showToast(data.error || 'Registration failed', 'error');
        }
    } catch (error) {
        console.error('Registration error:', error);
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

// My Registrations
async function loadMyRegistrations() {
    try {
        showLoading();
        const response = await fetch(`${API_BASE}/registrations/my`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        
        const registrations = await response.json();
        currentRegistrations = registrations;
        displayMyRegistrations(registrations);
    } catch (error) {
        console.error('Load registrations error:', error);
        showToast('Failed to load registrations', 'error');
    } finally {
        hideLoading();
    }
}

function displayMyRegistrations(registrations) {
    const container = document.getElementById('myRegistrationsList');
    
    if (registrations.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-ticket-alt"></i>
                <h3>No registrations yet</h3>
                <p>Browse events and register to see them here</p>
            </div>
        `;
        return;
    }

    container.innerHTML = registrations.map(registration => `
        <div class="registration-item">
            <div class="registration-info">
                <h4>${registration.title}</h4>
                <div class="registration-details">
                    <div><i class="fas fa-calendar"></i> ${formatDate(registration.date)}</div>
                    <div><i class="fas fa-clock"></i> ${formatTime(registration.time)}</div>
                    <div><i class="fas fa-map-marker-alt"></i> ${registration.location}</div>
                </div>
            </div>
            <button class="btn btn-danger" onclick="cancelRegistration(${registration.id})">
                Cancel Registration
            </button>
        </div>
    `).join('');
}

async function cancelRegistration(registrationId) {
    if (!confirm('Are you sure you want to cancel this registration?')) {
        return;
    }

    try {
        showLoading();
        const response = await fetch(`${API_BASE}/registrations/${registrationId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            showToast('Registration cancelled successfully', 'success');
            loadMyRegistrations();
            loadEvents(); // Reload events to update participant counts
        } else {
            showToast(data.error || 'Failed to cancel registration', 'error');
        }
    } catch (error) {
        console.error('Cancel registration error:', error);
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

// Admin Functions
async function loadAdminData() {
    await Promise.all([
        loadAdminStats(),
        loadAdminRegistrations()
    ]);
    loadEvents(); // This will also update admin events
}

async function loadAdminStats() {
    try {
        const response = await fetch(`${API_BASE}/admin/stats`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        
        const stats = await response.json();
        
        document.getElementById('totalEvents').textContent = stats.totalEvents;
        document.getElementById('totalUsers').textContent = stats.totalUsers;
        document.getElementById('totalRegistrations').textContent = stats.totalRegistrations;
        document.getElementById('upcomingEvents').textContent = stats.upcomingEvents;
    } catch (error) {
        console.error('Load stats error:', error);
    }
}

function displayAdminEvents(events) {
    const grid = document.getElementById('adminEventsGrid');
    if (!grid) return;
    
    if (events.length === 0) {
        grid.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-calendar-times"></i>
                <h3>No events available</h3>
            </div>
        `;
        return;
    }

    grid.innerHTML = events.map(event => `
        <div class="event-card">
            <div class="event-header">
                <div>
                    <h3 class="event-title">${event.title}</h3>
                </div>
                <span class="event-status status-${event.status}">${event.status}</span>
            </div>
            <div class="event-description">${event.description || 'No description'}</div>
            <div class="event-details">
                <div class="event-detail">
                    <i class="fas fa-calendar"></i>
                    <span>${formatDate(event.date)}</span>
                </div>
                <div class="event-detail">
                    <i class="fas fa-clock"></i>
                    <span>${formatTime(event.time)}</span>
                </div>
                <div class="event-detail">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${event.location}</span>
                </div>
            </div>
            <div class="event-footer">
                <div class="event-participants">
                    <i class="fas fa-users"></i>
                    ${event.registered_count || 0}${event.max_participants ? `/${event.max_participants}` : ''} registered
                </div>
                <div class="event-actions">
                    <button class="btn btn-warning" onclick="editEvent(${event.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-danger" onclick="deleteEvent(${event.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

async function loadAdminRegistrations() {
    try {
        const response = await fetch(`${API_BASE}/admin/registrations`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        
        const registrations = await response.json();
        displayAdminRegistrations(registrations);
    } catch (error) {
        console.error('Load admin registrations error:', error);
    }
}

function displayAdminRegistrations(registrations) {
    const tbody = document.getElementById('registrationsTableBody');
    
    if (registrations.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="4" style="text-align: center; padding: 2rem;">
                    No registrations found
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = registrations.map(reg => `
        <tr>
            <td>${reg.username} (${reg.email})</td>
            <td>${reg.event_title}</td>
            <td>${formatDate(reg.registration_date)}</td>
            <td>
                <span class="event-status status-${reg.status}">${reg.status}</span>
            </td>
        </tr>
    `).join('');
}

function showCreateEventForm() {
    showModal('createEventModal');
}

async function handleCreateEvent(e) {
    e.preventDefault();
    
    const eventData = {
        title: document.getElementById('eventTitle').value,
        description: document.getElementById('eventDescription').value,
        date: document.getElementById('eventDate').value,
        time: document.getElementById('eventTime').value,
        location: document.getElementById('eventLocation').value,
        max_participants: document.getElementById('eventMaxParticipants').value || null
    };

    try {
        showLoading();
        const response = await fetch(`${API_BASE}/events`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify(eventData)
        });

        const data = await response.json();

        if (response.ok) {
            showToast('Event created successfully!', 'success');
            closeModal('createEventModal');
            document.getElementById('createEventForm').reset();
            loadEvents();
        } else {
            showToast(data.error || 'Failed to create event', 'error');
        }
    } catch (error) {
        console.error('Create event error:', error);
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

async function deleteEvent(eventId) {
    if (!confirm('Are you sure you want to delete this event? This action cannot be undone.')) {
        return;
    }

    try {
        showLoading();
        const response = await fetch(`${API_BASE}/events/${eventId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            showToast('Event deleted successfully', 'success');
            loadEvents();
        } else {
            showToast(data.error || 'Failed to delete event', 'error');
        }
    } catch (error) {
        console.error('Delete event error:', error);
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

// Utility Functions
function showModal(modalId) {
    document.getElementById(modalId).classList.add('show');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('show');
}

function showLoading() {
    document.getElementById('loadingSpinner').classList.add('show');
}

function hideLoading() {
    document.getElementById('loadingSpinner').classList.remove('show');
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type}`;
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function formatTime(timeString) {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
}
