const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Check if running on Vercel
const isVercel = process.env.VERCEL === '1';

// Middleware
app.use(cors({
    origin: isVercel ? true : ['http://localhost:3000'],
    credentials: true
}));
app.use(express.json());
app.use(express.static('public'));

// Database connection
let db;

async function initDB() {
    try {
        db = await mysql.createConnection({
            host: process.env.DB_HOST || 'localhost',
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASSWORD || '',
            database: process.env.DB_NAME || 'event_registration'
        });
        console.log('Connected to MySQL database');
    } catch (error) {
        console.error('Database connection failed:', error);
        process.exit(1);
    }
}

// JWT Middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access token required' });
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Invalid token' });
        }
        req.user = user;
        next();
    });
};

// Admin Middleware
const requireAdmin = (req, res, next) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }
    next();
};

// Validation middleware
const handleValidationErrors = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};

// Routes

// Auth Routes
app.post('/api/auth/register', [
    body('username').isLength({ min: 3 }).trim(),
    body('email').isEmail().normalizeEmail(),
    body('password').isLength({ min: 6 })
], handleValidationErrors, async (req, res) => {
    try {
        const { username, email, password } = req.body;
        
        // Check if user exists
        const [existingUsers] = await db.execute(
            'SELECT id FROM users WHERE username = ? OR email = ?',
            [username, email]
        );
        
        if (existingUsers.length > 0) {
            return res.status(400).json({ error: 'Username or email already exists' });
        }
        
        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Create user
        const [result] = await db.execute(
            'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
            [username, email, hashedPassword]
        );
        
        res.status(201).json({ message: 'User created successfully', userId: result.insertId });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/api/auth/login', [
    body('username').trim(),
    body('password')
], handleValidationErrors, async (req, res) => {
    try {
        const { username, password } = req.body;
        
        // Find user
        const [users] = await db.execute(
            'SELECT id, username, email, password, role FROM users WHERE username = ? OR email = ?',
            [username, username]
        );
        
        if (users.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        const user = users[0];
        
        // Check password
        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        // Generate JWT
        const token = jwt.sign(
            { id: user.id, username: user.username, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );
        
        res.json({
            token,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Event Routes
app.get('/api/events', async (req, res) => {
    try {
        const [events] = await db.execute(`
            SELECT e.*, u.username as created_by_name,
                   (SELECT COUNT(*) FROM registrations WHERE event_id = e.id AND status = 'confirmed') as registered_count
            FROM events e
            LEFT JOIN users u ON e.created_by = u.id
            ORDER BY e.date ASC
        `);
        
        res.json(events);
    } catch (error) {
        console.error('Get events error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/events/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        const [events] = await db.execute(`
            SELECT e.*, u.username as created_by_name,
                   (SELECT COUNT(*) FROM registrations WHERE event_id = e.id AND status = 'confirmed') as registered_count
            FROM events e
            LEFT JOIN users u ON e.created_by = u.id
            WHERE e.id = ?
        `, [id]);
        
        if (events.length === 0) {
            return res.status(404).json({ error: 'Event not found' });
        }
        
        res.json(events[0]);
    } catch (error) {
        console.error('Get event error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/api/events', authenticateToken, requireAdmin, [
    body('title').notEmpty().trim(),
    body('description').optional(),
    body('date').isISO8601().toDate(),
    body('time').matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/),
    body('location').notEmpty().trim(),
    body('max_participants').optional().isInt({ min: 1 })
], handleValidationErrors, async (req, res) => {
    try {
        const { title, description, date, time, location, max_participants } = req.body;
        
        const [result] = await db.execute(
            'INSERT INTO events (title, description, date, time, location, max_participants, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [title, description, date, time, location, max_participants, req.user.id]
        );
        
        res.status(201).json({ message: 'Event created successfully', eventId: result.insertId });
    } catch (error) {
        console.error('Create event error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.put('/api/events/:id', authenticateToken, requireAdmin, [
    body('title').optional().notEmpty().trim(),
    body('description').optional(),
    body('date').optional().isISO8601().toDate(),
    body('time').optional().matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/),
    body('location').optional().notEmpty().trim(),
    body('max_participants').optional().isInt({ min: 1 }),
    body('status').optional().isIn(['upcoming', 'ongoing', 'completed', 'cancelled'])
], handleValidationErrors, async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;
        
        // Build dynamic update query
        const updateFields = [];
        const updateValues = [];
        
        Object.keys(updates).forEach(key => {
            updateFields.push(`${key} = ?`);
            updateValues.push(updates[key]);
        });
        
        if (updateFields.length === 0) {
            return res.status(400).json({ error: 'No valid fields to update' });
        }
        
        updateValues.push(id);
        
        const [result] = await db.execute(
            `UPDATE events SET ${updateFields.join(', ')} WHERE id = ?`,
            updateValues
        );
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Event not found' });
        }
        
        res.json({ message: 'Event updated successfully' });
    } catch (error) {
        console.error('Update event error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.delete('/api/events/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        
        const [result] = await db.execute('DELETE FROM events WHERE id = ?', [id]);
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Event not found' });
        }
        
        res.json({ message: 'Event deleted successfully' });
    } catch (error) {
        console.error('Delete event error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Registration Routes
app.post('/api/registrations', authenticateToken, [
    body('event_id').isInt()
], handleValidationErrors, async (req, res) => {
    try {
        const { event_id } = req.body;
        const user_id = req.user.id;
        
        // Check if event exists and has space
        const [events] = await db.execute(
            'SELECT max_participants, (SELECT COUNT(*) FROM registrations WHERE event_id = ? AND status = "confirmed") as registered_count FROM events WHERE id = ?',
            [event_id, event_id]
        );
        
        if (events.length === 0) {
            return res.status(404).json({ error: 'Event not found' });
        }
        
        const event = events[0];
        
        if (event.max_participants && event.registered_count >= event.max_participants) {
            return res.status(400).json({ error: 'Event is fully booked' });
        }
        
        // Check if already registered
        const [existingRegistrations] = await db.execute(
            'SELECT id FROM registrations WHERE event_id = ? AND user_id = ?',
            [event_id, user_id]
        );
        
        if (existingRegistrations.length > 0) {
            return res.status(400).json({ error: 'Already registered for this event' });
        }
        
        // Register for event
        const [result] = await db.execute(
            'INSERT INTO registrations (event_id, user_id) VALUES (?, ?)',
            [event_id, user_id]
        );
        
        res.status(201).json({ message: 'Successfully registered for event', registrationId: result.insertId });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/registrations/my', authenticateToken, async (req, res) => {
    try {
        const user_id = req.user.id;
        
        const [registrations] = await db.execute(`
            SELECT r.*, e.title, e.date, e.time, e.location, e.status as event_status
            FROM registrations r
            JOIN events e ON r.event_id = e.id
            WHERE r.user_id = ? AND r.status = 'confirmed'
            ORDER BY e.date ASC
        `, [user_id]);
        
        res.json(registrations);
    } catch (error) {
        console.error('Get my registrations error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.delete('/api/registrations/:id', authenticateToken, async (req, res) => {
    try {
        const { id } = req.params;
        const user_id = req.user.id;
        
        const [result] = await db.execute(
            'UPDATE registrations SET status = "cancelled" WHERE id = ? AND user_id = ?',
            [id, user_id]
        );
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Registration not found' });
        }
        
        res.json({ message: 'Registration cancelled successfully' });
    } catch (error) {
        console.error('Cancel registration error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Admin Dashboard Routes
app.get('/api/admin/stats', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const [totalEvents] = await db.execute('SELECT COUNT(*) as count FROM events');
        const [totalUsers] = await db.execute('SELECT COUNT(*) as count FROM users');
        const [totalRegistrations] = await db.execute('SELECT COUNT(*) as count FROM registrations WHERE status = "confirmed"');
        const [upcomingEvents] = await db.execute('SELECT COUNT(*) as count FROM events WHERE date >= CURDATE() AND status = "upcoming"');
        
        res.json({
            totalEvents: totalEvents[0].count,
            totalUsers: totalUsers[0].count,
            totalRegistrations: totalRegistrations[0].count,
            upcomingEvents: upcomingEvents[0].count
        });
    } catch (error) {
        console.error('Get stats error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/admin/registrations', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const [registrations] = await db.execute(`
            SELECT r.*, u.username, u.email, e.title as event_title, e.date as event_date
            FROM registrations r
            JOIN users u ON r.user_id = u.id
            JOIN events e ON r.event_id = e.id
            ORDER BY r.registration_date DESC
        `);
        
        res.json(registrations);
    } catch (error) {
        console.error('Get all registrations error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Serve frontend
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

// Start server
async function startServer() {
    await initDB();
    
    if (isVercel) {
        // Export for Vercel serverless
        module.exports = app;
        console.log('Server ready for Vercel deployment');
    } else {
        // Start local server
        app.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
            console.log(`Visit http://localhost:${PORT} to access the application`);
        });
    }
}

startServer().catch(console.error);

// Export for Vercel
if (isVercel) {
    module.exports = app;
}
