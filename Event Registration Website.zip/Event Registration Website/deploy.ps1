# Event Registration Website Deployment Script

Write-Host "🚀 Event Registration Website Deployment" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Yellow
Write-Host ""

Write-Host "📋 STEPS TO FOLLOW:" -ForegroundColor Cyan
Write-Host "1. Create GitHub repository named 'event-registration-website'"
Write-Host "2. Create PlanetScale database"
Write-Host "3. Deploy to Vercel"
Write-Host ""

Write-Host "🌐 GitHub Setup:" -ForegroundColor Cyan
Write-Host "1. Go to https://github.com and create a new repository"
Write-Host "2. Name it 'event-registration-website'"
Write-Host "3. Make it public"
Write-Host "4. Copy the repository URL"
Write-Host ""

Write-Host "📤 Once you have the GitHub URL, run these commands:" -ForegroundColor Yellow
Write-Host "git remote set-url origin YOUR_GITHUB_REPO_URL"
Write-Host "git push -u origin main"
Write-Host ""

Write-Host "🗄️ PlanetScale Setup:" -ForegroundColor Cyan
Write-Host "1. Go to https://planetscale.com"
Write-Host "2. Sign up for free account"
Write-Host "3. Create database 'event-registration'"
Write-Host "4. Import database.sql file"
Write-Host "5. Get connection details"
Write-Host ""

Write-Host "🚀 Vercel Deployment:" -ForegroundColor Cyan
Write-Host "1. Go to https://vercel.com"
Write-Host "2. Import your GitHub repository"
Write-Host "3. Set environment variables from PlanetScale"
Write-Host "4. Deploy!"
Write-Host ""

Write-Host "📧 Environment Variables needed in Vercel:" -ForegroundColor Yellow
Write-Host "DB_HOST=your_planetscale_host"
Write-Host "DB_USER=your_planetscale_username"
Write-Host "DB_PASSWORD=your_planetscale_password"
Write-Host "DB_NAME=event_registration"
Write-Host "JWT_SECRET=your_random_secret_key"
Write-Host "VERCEL=1"
Write-Host ""

Write-Host "🎯 Your app will be available at:" -ForegroundColor Green
Write-Host "https://your-project-name.vercel.app"
Write-Host ""

Write-Host "📚 Full guide available in DEPLOYMENT.md" -ForegroundColor Blue
