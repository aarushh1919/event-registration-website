# Vercel Deployment Guide

## 🚀 Deploy Event Registration Website to Vercel

### **Prerequisites**
- Vercel account (free)
- GitHub account
- MySQL database (cloud-based recommended)

### **Step 1: Database Setup for Production**

Since Vercel is serverless, you need a cloud MySQL database:

#### **Option A: PlanetScale (Recommended)**
1. Sign up at [PlanetScale](https://planetscale.com/)
2. Create a new database
3. Get connection details
4. Import schema using PlanetScale console

#### **Option B: Railway**
1. Sign up at [Railway](https://railway.app/)
2. Add MySQL service
3. Get connection details
4. Import schema

#### **Option C: AWS RDS**
1. Create AWS account
2. Launch RDS MySQL instance
3. Configure security groups
4. Import schema

### **Step 2: Push to GitHub**

1. Create a new repository on GitHub
2. Push your code:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/yourusername/event-registration.git
git push -u origin main
```

### **Step 3: Deploy to Vercel**

1. **Install Vercel CLI** (optional):
```bash
npm i -g vercel
```

2. **Deploy via Vercel Dashboard**:
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Import your GitHub repository
   - Configure environment variables
   - Click "Deploy"

3. **Environment Variables** (in Vercel Dashboard):
```
DB_HOST=your_cloud_mysql_host
DB_USER=your_mysql_username
DB_PASSWORD=your_mysql_password
DB_NAME=event_registration
JWT_SECRET=your_jwt_secret_key
NODE_ENV=production
VERCEL=1
```

### **Step 4: Verify Deployment**

After deployment, your app will be available at:
- `https://your-project-name.vercel.app`

### **Troubleshooting**

#### **Database Connection Issues**
- Ensure MySQL allows remote connections
- Check firewall settings
- Verify connection string format

#### **CORS Issues**
- The app is configured for both local and Vercel environments
- No additional CORS configuration needed

#### **Build Errors**
- Check all dependencies are in package.json
- Ensure .env variables are set correctly in Vercel

### **Custom Domain (Optional)**

1. In Vercel Dashboard → Settings → Domains
2. Add your custom domain
3. Configure DNS records as instructed

### **Database Migration**

To migrate your local database to cloud:

```sql
# Export local data
mysqldump -u root -p event_registration > backup.sql

# Import to cloud (varies by provider)
# Use your cloud provider's import tool
```

## 🎯 Production Considerations

### **Security**
- Use strong JWT secrets
- Enable SSL on database connections
- Regular database backups
- Monitor for suspicious activity

### **Performance**
- Consider database connection pooling
- Implement caching for frequently accessed data
- Monitor Vercel function execution times

### **Scaling**
- Vercel automatically scales serverless functions
- Consider database read replicas for high traffic
- Implement CDN for static assets

## 📞 Support

- Vercel Documentation: https://vercel.com/docs
- PlanetScale Documentation: https://docs.planetscale.com
- GitHub Issues: Create issues in your repository

---

**Note**: This deployment requires a cloud MySQL database. The free tier of PlanetScale or Railway should be sufficient for development and small projects.
