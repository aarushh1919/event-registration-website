#!/bin/bash

# Event Registration Website Deployment Script

echo "🚀 Event Registration Website Deployment"
echo "=========================================="

echo ""
echo "📋 STEPS TO FOLLOW:"
echo "1. Create GitHub repository named 'event-registration-website'"
echo "2. Create PlanetScale database"
echo "3. Deploy to Vercel"
echo ""

echo "🌐 GitHub Setup:"
echo "1. Go to https://github.com and create a new repository"
echo "2. Name it 'event-registration-website'"
echo "3. Make it public"
echo "4. Copy the repository URL"
echo ""

echo "📤 Once you have the GitHub URL, run these commands:"
echo "git remote set-url origin YOUR_GITHUB_REPO_URL"
echo "git push -u origin main"
echo ""

echo "🗄️ PlanetScale Setup:"
echo "1. Go to https://planetscale.com"
echo "2. Sign up for free account"
echo "3. Create database 'event-registration'"
echo "4. Import database.sql file"
echo "5. Get connection details"
echo ""

echo "🚀 Vercel Deployment:"
echo "1. Go to https://vercel.com"
echo "2. Import your GitHub repository"
echo "3. Set environment variables from PlanetScale"
echo "4. Deploy!"
echo ""

echo "📧 Environment Variables needed in Vercel:"
echo "DB_HOST=your_planetscale_host"
echo "DB_USER=your_planetscale_username"
echo "DB_PASSWORD=your_planetscale_password"
echo "DB_NAME=event_registration"
echo "JWT_SECRET=your_random_secret_key"
echo "VERCEL=1"
echo ""

echo "🎯 Your app will be available at:"
echo "https://your-project-name.vercel.app"
echo ""

echo "📚 Full guide available in DEPLOYMENT.md"
